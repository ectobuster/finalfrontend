The Rota font can only be downloaded and used from permitted link addresses. Other users may not duplicate the Rota font and publish it on their pages without permission.

All rights belong to Serdar Ozturk.

https://www.behance.net/srdroztrk

http://www.arodora.com/

http://instagram.com/arodoragency