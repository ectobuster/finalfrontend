import * as React from 'react';
import Box from '@mui/material/Box';
import AddReactionIcon from '@mui/icons-material/AddReaction';
import AltRouteIcon from '@mui/icons-material/AltRoute';
import BackHandIcon from '@mui/icons-material/BackHand';
import Container from '@mui/material/Container';
import './organisms.css'


export default function B1() {
    return (
<div className="Seccion ">
    <div  className="contenedor-flex fondoblanco" >
      <Box className='H1titulo' margin={10}>Que me hace diferente? </Box>

    </div> 
    <br/>    
    <div  className="contenedor-flex fondoblanco" >
      <div  className="contenedor-flexV">
      <AddReactionIcon fontSize='large'></AddReactionIcon>
        <br /><div className='H3'>
            Experiencia de usuario</div>
      </div>
      <div  className="contenedor-flexV">
        <AltRouteIcon fontSize='large'></AltRouteIcon>
        <br /><div className='H3'>
            Determinado y resolutivo</div>
      </div>
      <div  className="contenedor-flexV">
        <BackHandIcon fontSize='large'></BackHandIcon>
        <br /><div className='H3'>
            Colaborador y proactivo</div>
      </div>
    </div>        
</div>
      );
}