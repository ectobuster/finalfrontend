export default interface IUsuarios {
  idusuario:   number;
  nombre:      string;
  email:       string;
  contrasenia: string;
  foto:        string;
  estado:      number;
  createdAt:   Date;
  updatedAt:   Date;

}