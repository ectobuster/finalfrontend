export default interface IRoles {
  idrol:     number;
  nombre:    string;
  createdAt: Date;
  updatedAt: Date;
}