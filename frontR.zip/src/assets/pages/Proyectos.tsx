import * as React from 'react';

import D1 from '../../components/organisms/D1';
import D2 from '../../components/organisms/D2';
import B5 from '../../components/organisms/B5';
import B6 from '../../components/organisms/B6';

function Proyectos() {

    return (
      <div>
          <D1/>
          <D2/>
          <B5/>
          <B6/>
      </div>
    )
  }
  
  export default Proyectos