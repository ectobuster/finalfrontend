import { BrowserRouter as Router, Route, Routes, } from 'react-router-dom';
import Barra from './components/organisms/barra';
import Inicio from './assets/pages/Inicio';
import InicioB from './assets/pages/InicioB';
import Acercademi from './assets/pages/Acercademi';
import Proyectos from './assets/pages/Proyectos';



function App() {

  return (
    <Router>
      <div>
        <Barra />
      <Routes>
        <Route path="/" element={<Inicio/>} />
        <Route path="/inicio" element={<Inicio/>} />
        <Route path="/proyectos" element={<Proyectos/>} />
        <Route path="/acerca de mi" element={<Acercademi/>} />
      </Routes>
      </div>
    </Router>
  );
}

export default App
